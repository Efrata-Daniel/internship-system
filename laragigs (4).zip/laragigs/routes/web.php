<?php

use App\Models\Listing;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ListingController;
use App\Http\Controllers\applyinternship;
use App\Http\Controllers\ReportGenerate;
use App\Models\report;
use App\Http\Controllers\GradeStudent; 
use App\Models\grade_student;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//all listings
Route::get('/', [ListingController::class, 'index']);

//show created form
Route::get('/listings/create', [ListingController::class, 'create'])->middleware('auth');

//store listing data
Route::post('/listings', [ListingController::class, 'store'])->middleware('auth');

//show edit form
Route::get('/listings/{listing}/edit', [ListingController::class, 'edit'])->middleware('auth');

//update listing
Route::put('/listings/{listing}', [ListingController::class, 'update'])->middleware('auth');

//delete listing
Route::delete('/listings/{listing}', [ListingController::class, 'destroy'])->middleware('auth');

//manage listings
Route::get('/listings/manage', [ListingController::class, 'manage'])->middleware('auth');

//single listings
Route::get('/listings/{listing}', [ListingController::class, 'show']);

//Show Register/Crete Form
Route::get('/register', [UserController::class, 'create'])->middleware('guest');

//create new user
Route::post('/users', [UserController::class, 'store']);

//logout user
Route::post('/logout', [UserController::class, 'logout'])->middleware('auth');

//login form

Route::get('/login', [UserController::class, 'login'])->name('login')->middleware('guest');

//login user

Route::post('/users/authenticate', [UserController::class, 'authenticate']);


//Route::get('/applyinternship-form', 'applyinternship@showForm');
//Route::post('/applyinternship-form', 'applyinternship@submitForm');


//Route::get('/view/{name}', [applyinternship::class, 'view'])->name('view');


Route::get('/applyinternship-form', [applyinternship::class, 'showForm'])->name('applyinternship-form');
//Route::post('/applyinternship-form', [applyinternship::class, 'submitForm'])->name('applyinternship-forms');
Route::post('/applyinternship-form', [applyinternship::class, 'submitForm'])->name('applyinternship-forms');

//Route::get('/accept', [applyinternship::class, 'showAccept'])->name('applyinternship-form');

//Route::get('/accept',[applyinternship::class, 'showForm'])->name('accept');



Route::get('/accept', function () {
    return view('accept');
});

Route::get('/supervisor', function () {
    return view('supervisor');
});
Route::get('/generate-report', function () {
    return view('generate-report');
});

Route::post('/generate-report', [ReportGenerate::class, 'submitForms'])->name('generate-report');


// Route::post('/generate-report', [generatereport::class, 'submitForms'])->name('generate-reports');

Route::get('/grade', function () {
    return view('grade');
});

 Route::post('/grade', [GradeStudent::class, 'submitFormss'])->name('grade');

// Route::post('/form', [form::class, 'form'])->name('x');
// Route::get('/form', function () {
//     return view('form');
// });
// Route::get('/form', function () {
//     return view('form');
// });


//Route::get('/form', function () {
  //  return view('form');
//});
// Route::get('/form', [applyinternship::class, 'a']);
// //Route::post('/applyinternship-form', [applyinternship::class, 'submitForm'])->name('applyinternship-forms');
// Route::post('/form', [applyinternship::class, 'b'])->name('applyinternships-forms');
Route::get('/see', function () {
    return view('see');
});

Route::get('/advisor-grade', function () {
    return view('/advisor-grade');
});
Route::get('/accept', function () {
    // Fetch data from the MySQL table
    $datas = DB::table('apply_internship')->get();

    // Return the data to the view
    return view('accept', ['datas' => $datas]);
});