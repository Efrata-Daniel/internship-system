
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('grade_student', function (Blueprint $table) {
            $table->id();
            $table->string(' company_name');
            $table->string('supervisor_name');
            $table->string('  student_name');
            $table->string(' student_department');
            $table->string('Punctuality');
            $table->string('Independence');
            $table->string('Speed');

            $table->string('Doyou');
            $table->string('Technical');
            $table->string('Organizing');

            $table->string('Problem');
            $table->string('Responsibility');
            $table->timestamps();
            // $table->unsignedBigInteger('user_id');
            // $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

            // company-name
            // supervisor-name
            // student-name
            // student-department
            // Punctuality
            // Independence
            // Speed
            // Doyou
            // Technical
            // Organizing
            // Problem
            // Responsibility
     
     
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('grade_student');
    }
};


