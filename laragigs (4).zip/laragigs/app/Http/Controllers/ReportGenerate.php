<?php

namespace App\Http\Controllers;
use App\Models\report;
use Illuminate\Http\Request;

class ReportGenerate extends Controller
{
    public function showForm()
    {
       // $apply_internship = apply_internship::select('name')->get();
    
       return view('generate-report');
    }
    public function submitForms(Request $request)
    {

      //  dd($request);
        $request->validate([
            'Fullname' => 'required',
            'Department' => 'required',
            'Working' => 'required',
            'Shift' => 'required',
            'Absent ' => 'required',
            'Supervisorname' => 'required',
            'Reportsummary' => 'required'
          
        ]);

        report::create(
            [
                'Full_name'=>$request->Fullname,
                'Department'=>$request->Department,           
                'Working_on'=>$request->Working,
                'Shift'=>$request->Shift,
                'Absent'=>$request->Absent,
                'Supervisor_name'=>$request->Supervisorname,
                'Report_summary'=>$request->Reportsummary
            ]
            );
            return redirect('/generate-report')->with('success', 'Form submitted successfully!');
     }
}


