<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GradeStudent extends Controller
{
     
    public function submitFormss(Request $request)
{
    $validatedData = $request->validate([
        'company-name' => 'required',
        'supervisor-name' => 'required',
        'student-name' => 'required',
        'student-department' => 'required',
        'Punctuality ' => 'required',
        'Independence' => 'required',
        'Speed' => 'required',
        'Doyou ' => 'required',
        'Technical' => 'required',
        'Organizing' => 'required',
        'Problem' => 'required',
        'Responsibility' => 'required',


       // 'file' => 'required|mimes:pdf|max:2048',

    //    company-name
    //    supervisor-name
    //    student-name
    //    student-department
    //    Punctuality
    //    Independence
    //    Speed
    //    Doyou
    //    Technical
    //    Organizing
    //    Problem
    //    Responsibility
    ]);

    //id,  companyname, supervisorname,   studentname,  studentdepartment, Punctuality, Independence, Speed, Doyou, Technical, Organizing, Problem, Responsibility, created_at, updated_at, user_id
    $grade = new grade_student;
    $grade-> company_name  = $validatedData[' company-name'];
    $grade->supervisor_name = $validatedData[' supervisor-name'];
    
    $grade->student_name = $validatedData['student-name'];
    $grade->student_department = $validatedData['student-department'];
    $grade->Punctuality = $validatedData['Punctuality'];
    $grade->Independence = $validatedData['Independence'];
    $grade->Speed = $validatedData['Speed'];
     $grade->Doyou = $validatedData['Doyou'];
     $grade->Technical = $validatedData['Technical'];
      $grade->Organizing = $validatedData['Organizing'];
      $grade->Problem = $validatedData['Problem'];
     $grade->Responsibility = $validatedData['Responsibility'];

     $grade->user_id =1;
     $grade->created_at = now();
     $grade->updated_at = now();
    

    $grade->save();
    
}
}
