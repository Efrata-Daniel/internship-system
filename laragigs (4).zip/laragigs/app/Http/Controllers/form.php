<?php

namespace App\Http\Controllers;
use App\Models\apply_internship;
//use App\Models\generate_report;
use Illuminate\Http\Request;

class applyinternship extends Controller
{public function a()
    {
       // $apply_internship = apply_internship::select('name')->get();
    
       return view('applyinternship-form');
    }
    public function b(Request $request)
{
    $validatedData = $request->validate([
        'name' => 'required',
        'department' => 'required',
        'student-email' => 'required|email',
        'advisor-name' => 'required',
        'advisor-email' => 'required|email',
       // 'file' => 'required|mimes:pdf|max:2048',
    ]);


    $apply_internship = new apply_internship;
    $apply_internship->name  = $validatedData['name'];
    $apply_internship->student_email = $validatedData['student-email'];
    $apply_internship->advisor_name = $validatedData['advisor-name'];
    $apply_internship->advisor_email = $validatedData['advisor-email'];
    $apply_internship->department = $validatedData['department'];
    $apply_internship->file_path = "path";
    $apply_internship->save();
    return redirect('/applyinternship-form')->with('success', 'Form submitted successfully!');
}
public function submitForms(Request $request)
{
    $validatedData = $request->validate([
        // 'Fullname' => 'required',
        // 'Department' => 'required',
        // 'Workingon' => 'required|email',
        // 'Shift' => 'required',
        // 'Absent ' => 'required|email',
        // 'Supervisorname' => 'required|email',
        // 'Reportsummary' => 'required|email',
       // 'file' => 'required|mimes:pdf|max:2048',
    ]);

// id, Fullname, Department, Workingon, Shift, Absent, Supervisorname, Reportsummary, created_at, updated_at, user_id
    // $generate_report = new generate_report;
    // $generate_report->Fullname  = $validatedData['Fullname'];
    // $generate_report->Department = $validatedData['Department'];
    // $generate_report->Workingon = $validatedData['Workingon'];
    // $generate_report->Shift = $validatedData['Shift'];
    // $generate_report->Absent = $validatedData['Absent'];
    // $generate_report->Supervisorname = $validatedData['Supervisorname'];
    // $generate_report->Reportsummary = $validatedData['Reportsummary'];
    // $generate_report->user_id = Auth::user()->id;
    // $generate_report->created_at = now();
    // $generate_report->updated_at = now();
    // $x->save();
    //     return redirect('/generate-report')->with('success', 'Form submitted successfully!');
 }
}


