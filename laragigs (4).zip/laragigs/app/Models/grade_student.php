<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class grade_student extends Model
{public $table = 'grade_student';
    // public $timestamps=false;
// id,  companyname, supervisorname,   studentname,  studentdepartment, Punctuality, Independence, Speed, Doyou, Technical, Organizing, Problem, Responsibility, created_at, updated_at, user_id
        protected $fillable = [ 
        'company_name',
        'supervisor_name',
        'student_name',
        'student_department',
        'Punctuality',
        'Independence',
        'Speed',
        'Doyou',
        'Technical',
        'Organizing',
        'Problem',
        'Responsibility',
//  'created_at',
//  'updated_at',
//  'user_id',
 
 ];
        use HasFactory, Notifiable;
}