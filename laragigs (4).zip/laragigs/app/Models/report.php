<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
class report extends Model
{
  
    use HasFactory;
    public $table = 'report';
    public $timestamps=false;

       
        use HasFactory, Notifiable;
         protected $fillable = [ 'Full_name', 'Department', 'Working_on', 'Shift', 'Absent', 'Supervisor_name', 'Report_summary'];
        
}
