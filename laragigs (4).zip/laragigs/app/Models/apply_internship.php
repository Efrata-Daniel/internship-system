<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
class apply_internship extends Model
{ 
    public $table = 'apply_internship';
    public $timestamps=false;

        protected $fillable = ['name', 'department', 'student_email', 'advisor_name', 'advisor_email', 'file_path'];
        use HasFactory, Notifiable;
    
    

}
