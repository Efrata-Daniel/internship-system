<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <script src="https://cdn.tailwindcss.com"></script> 
  <title>@yield('title')</title>
<base href="{{ \URL::to('/') }}">
<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
crossorigin="anonymous"
referrerpolicy="no-referrer"
/>
<script src="//unpkg.com/alpinejs" defer></script>
<script src="https://cdn.tailwindcss.com"></script>
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<style>
    .back-button {
  display: inline-block;
  padding: 10px 20px;
  background-color: #f2f2f2;
  color: #333;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
}

.back-button:hover {
  background-color: #ddd;
}</style>

<body class="hold-transition sidebar-mini">



<div class="wrapper">

  <div class="content-wrapper">
    <div class="min-h-screen p-6 bg-gray-100 flex items-center justify-center">
        <div class="container max-w-screen-lg mx-auto">
          <div>



          <a href="/supervisor" class="back-button">Back</a>
  <div class="container">
            <h2 class="font-semibold text-xl text-gray-600">Generate Report</h2>
           
      
            <div class="bg-white rounded shadow-lg p-4 px-4 md:p-8 mb-6">
              <div class="grid gap-4 gap-y-2 text-sm grid-cols-1 lg:grid-cols-3">
                <div class="text-gray-600">
                  <p class="font-medium text-lg" style="padding-left:40px;">Generate Report Form</p>
                  <img src="{{asset('images/report.png')}}" alt="sideimage">
                </div>
      
                <div class="lg:col-span-2">
                  <form action="{{route('generate-report')}}" method="POST"   enctype="multipart/form-data">
                  
                    @csrf
                  <div class="grid gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-5">
                  
                    <div class="md:col-span-5">
                      <label for="last_name">Full Name</label>
                      <input type="text" name="Fullname" id="full_name" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="Full Name"/>
                    </div>
                     <div class="md:col-span-5">
                      <label for="email">Department</label>
                      <input type="text" name="Department" id="floor" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="Department" />
                    </div>
                    
                    <div class="md:col-span-5">
                      <label for="email">Working on</label>
                      <input type="text" name="Working" id="email" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="Front-end" />
                    </div>
                   
                    
                    <div class="md:col-span-5">
                      <label for="email">Shift</label>
                      <input type="text" name="Shift" id="email" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="Front-end" />
                    </div>


                    <!-- <div class="md:col-span-2">
                      <label for="city">Shift</label>
                      <select name="Shift" id="pos" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50">
                        <option value="Technician">Morning</option>
                         <option value="Technician">Afternoon</option>
                          <option value="Technician">FullDay</option>
                      </select> -->
                      @error('position')
                      <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
              @enderror
                    </div>
      
                    <div class="md:col-span-3">
                      <label for="city">Absent days within the week</label>
                      <input type="text" name="Absent" id="city" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="0" />
                    </div>
                   
                    <div class="md:col-span-5">
                      <label for="country">Supervisor name</label>
                      <input type="text" name="Supervisorname" id="address" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="Supervisor name." />
                    </div>
      
      
                    <div class="md:col-span-5">
                      <label for="city">Report Summary</label>
                      <textarea name="Reportsummary" id="" cols="30" rows="10" class="h-30 border mt-1 rounded px-4 w-full bg-gray-50" placeholder="Write a short summary of the intern..." style="resize: none;"></textarea>
                     
                    </div>
      
                    
      
            
                    <div class="md:col-span-5 text-right">
                      <div class="inline-flex items-end">
                        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Generate Report</button>
                      </div>
                    </div>
      



                    <div class="md:col-span-5 text-right">
                      <div class="inline-flex items-end">
                        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"><a href="{{route('grade')}}"> Grade</a></button>
                      </div>
                    </div>
                  </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
      
          
        </div>
  </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper --><!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
 
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>