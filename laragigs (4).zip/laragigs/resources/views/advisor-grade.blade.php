<!DOCTYPE html>
<html>
<head>
  <title>Internship prformance Form</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    
    form {
      max-width: 400px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
    }
    
    h1 {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    label {
      display: block;
      font-weight: light;
    }
    
    input[type="text"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    
    button[type="submit"] {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    button[type="submit"]:hover {
      background-color: #45a049;
    }

    
    .back-button {
  display: inline-block;
  padding: 10px 20px;
  background-color: #f2f2f2;
  color: #333;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
}

.back-button:hover {
  background-color: #ddd;
}
  </style>
</head>
<body>
<a href="/see" class="back-button">Back</a>
  <div class="container">
  <form  action="{{route('grade')}}" method="post"  enctype="multipart/form-data"  >
    @csrf
    <h3>Internship Performance Form</h3>
    
    <div class="form-group">
      <label for="student-name">Student Name:</label>
      <input type="text" id="student-name" name="student-name" placeholder="grade" required>
    </div>
    <div class="form-group">
      <label for="student-department">Student Department:</label>
      <input type="text" id="student-department" name="student-department" placeholder="grade" required>
   
  

  
    <h3>General Performance (10%)</h3>
    <div class="form-group">
      <label for="company-name"> Punctuality and Reliability (5%):</label>
      <input type="text" id="company-name" name="Punctuality" placeholder="grade" required>
    </div>
    <div class="form-group">
      <label for="supervisor-name">Independence in Work; Communication skill 
and Professionalism (5%):</label>
      <input type="text" id="supervisor-name" name="Independence" placeholder="grade" required>
    </div>
   
    

    
    <h3>Personal Performance (10%)</h3>
    <div class="form-group">
      <label for="company-name"> Speed of Work; Accuracy; Engagement (5%):</label>
      <input type="text" id="company-name" name="Speed" placeholder="grade" required>
    </div>
    <div class="form-group">
      <label for="supervisor-name">Do you recommend him for your work; 
Cooperating with colleagues (5%):</label>
      <input type="text" id="supervisor-name" name="Doyou" placeholder="grade" required>
    </div>
   
    

    
    <h3>Professional Skills (20%)</h3>
    <div class="form-group">
      <label for="company-name"> Technical Skills (5%):</label>
      <input type="text" id="company-name" name="Technical" placeholder="grade" required>
    </div>
    <div class="form-group">
      <label for="supervisor-name">Organizing skills (5%):</label>
      <input type="text" id="supervisor-name" name="Organizing" placeholder="grade" required>
    </div>
    <div class="form-group">
      <label for="student-name">Problem solving skills (5%):</label>
      <input type="text" id="student-name" name="Problem" placeholder="grade" required>
    </div>
    <div class="form-group">
      <label for="student-department">Responsibility in task-fulfillments (5%):</label>
      <input type="text" id="student-department" name="Responsibility" placeholder="grade" required>
    </div>
    <button type="submit">Submit</button>
  </form>




</body>
</html>
