<!DOCTYPE html>
<html>
<head>
  <title>Application Form</title>
  <style>

    .container {
      max-width: 400px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .form-group {
      margin-bottom: 15px;
    }
    
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }
    
    input[type="text"], input[type="email"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    
    .file-input {
      display: block;
      margin-top: 10px;
    }
    
    input[type="file"] {
      width: 100%;
      padding: 5px;
    }
    
    input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    .back-button {
  display: inline-block;
  padding: 10px 20px;
  background-color: #f2f2f2;
  color: #333;
  text-decoration: none;
  border-radius: 5px;
  font-weight: bold;
}

.back-button:hover {
  background-color: #ddd;
}
  </style>
</head>
<body>
<a href="/" class="back-button">Back</a>
  <div class="container">
    <h2>Application Form</h2>
    <form action="{{route('applyinternship-forms')}}" method="POST" enctype="multipart/form-data">
      @csrf
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
      </div>
      <div class="form-group">
        <label for="department">Department:</label>
        <input type="text" id="department" name="department" required>
      </div>
      <div class="form-group">
        <label for="student-email">Student Email:</label>
        <input type="email" id="student-email" name="student-email" required>
      </div>
      <div class="form-group">
        <label for="advisor-name">Advisor Name:</label>
        <input type="text" id="advisor-name" name="advisor-name" required>
      </div>
      <div class="form-group">
        <label for="advisor-email">Advisor Email:</label>
        <input type="email" id="advisor-email" name="advisor-email" required>
      </div>
      <!-- <div class="form-group">
        <label for="file">Choose File:</label>
        <input type="file" id="file" name="file" class="file-input" required>
      </div> -->
      <input type="submit" value="Apply">

      
    </form>
  </div>
</body>
</html>