<!DOCTYPE html>
<html>
<head>
    <title>View Student Form</title>
</head>
<body>
    <h1>View Student Form</h1>

    <h2>{{ $apply_internship->name }}</h2>

    <p>Department: {{ $apply_internship->department }}</p>
    <p>Student Email: {{ $apply_internship->student_email }}</p>
    <p>Advisor Name: {{ $apply_internship->advisor_name }}</p>
    <p>Advisor Email: {{ $apply_internship->advisor_email }}</p>

    <!-- Display any additional form fields as needed -->

    <p>File: <a href="{{ Storage::url($apply_internship->file_path) }}" target="_blank">Download</a></p>

    <a href="{{ route('applyinternship-form') }}">Go Back</a>
</body>
</html>
